package org.example.practicacalculadora.controller;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;


public class CalcuController implements Initializable {
    @FXML
    private Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn00;

    @FXML
    private Button btnAc, btnC;

    @FXML
    private Button btnCoseno, btnSeno, btnRaiz, btnPotencia;

    @FXML
    private Button btnDividir, btnMultiplicar, btnSuma, btnRestar;

    @FXML
    private Button btnIgual;

    @FXML
    private Button btnOff;

    @FXML
    private Button btnPunto;

    @FXML
    private BorderPane panelGeneral;

    @FXML
    private GridPane panelCientifica;

    @FXML
    private TextField textOperacion;

    @FXML
    private TextField textResultado;

    @FXML
    private ToggleButton toggleCambio;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        instancias();
        initgui();
        acciones();
    }

    private void acciones() {

        toggleCambio.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                if(newValue){
                    panelGeneral.setLeft(panelCientifica);
                }
                else{
                    panelGeneral.setLeft(null);
                }
            }
        });

        //numeros
        btn0.setOnAction(new ManejadorAcciones());
        btn00.setOnAction(new ManejadorAcciones());
        btn1.setOnAction(new ManejadorAcciones());
        btn2.setOnAction(new ManejadorAcciones());
        btn3.setOnAction(new ManejadorAcciones());
        btn4.setOnAction(new ManejadorAcciones());
        btn5.setOnAction(new ManejadorAcciones());
        btn6.setOnAction(new ManejadorAcciones());
        btn7.setOnAction(new ManejadorAcciones());
        btn8.setOnAction(new ManejadorAcciones());
        btn9.setOnAction(new ManejadorAcciones());

        // Operadores y punto
        btnSuma.setOnAction(new ManejadorAcciones());
        btnRestar.setOnAction(new ManejadorAcciones());
        btnMultiplicar.setOnAction(new ManejadorAcciones());
        btnDividir.setOnAction(new ManejadorAcciones());
        btnPunto.setOnAction(new ManejadorAcciones());

        // Controles
        btnC.setOnAction(new ManejadorAcciones());
        btnAc.setOnAction(new ManejadorAcciones());
        btnIgual.setOnAction(new ManejadorAcciones());
        btnOff.setOnAction(new ManejadorAcciones());

        // Científicos
        btnCoseno.setOnAction(new ManejadorAcciones());
        btnSeno.setOnAction(new ManejadorAcciones());
        btnRaiz.setOnAction(new ManejadorAcciones());
        btnPotencia.setOnAction(new ManejadorAcciones());
    }

    private void initgui() {
        panelGeneral.setLeft(null);
    }

    private void instancias() {
    }

    class ManejadorAcciones implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent actionEvent) {
            Button boton = (Button) actionEvent.getSource();
            String id = boton.getId();

            switch (id) {
                case "btn0", "btn00", "btn1", "btn2", "btn3", "btn4",
                     "btn5", "btn6", "btn7", "btn8", "btn9" -> botonNumerico(boton);

                case "btnSuma", "btnRestar", "btnMultiplicar", "btnDividir", "btnPunto" -> botonOperacion(boton);

                case "btnC" -> textOperacion.setText("");

                case "btnAc" -> limpiarTodo(boton);

                case "btnOff" -> Platform.exit();

                case "btnIgual" -> pulsarIgual(boton);

                case "btnCoseno", "btnPotencia", "btnSeno", "btnRaiz" -> botonCiencitico(boton);
            }
        }
    }

    //METODOS ADICIONALES

    private void botonNumerico(Button botonPulsado) {
        String numero = botonPulsado.getText();
        textOperacion.appendText(numero);
    }

    private void botonOperacion(Button boton) {
        String signo = boton.getText();
        String operacion = textOperacion.getText();

        if (operacion != null && !operacion.isEmpty()) {
            char ultimo = operacion.charAt(operacion.length() - 1);
            boolean ultimoEsOperador = ultimo == '-' || ultimo == '+' || ultimo == '/' || ultimo == '*' || ultimo == '√' || ultimo == '.';
            boolean contieneFuncion = operacion.contains("sen") || operacion.contains("cos") || operacion.contains("pow");

            if (!ultimoEsOperador && !contieneFuncion) {
                textOperacion.appendText(signo);
            }
        }
    }

    private void botonCiencitico(Button boton) {
        String operacion = textOperacion.getText();

        if (!operacion.isEmpty()
                && !operacion.contains("+")
                && !operacion.contains("-")
                && !operacion.contains("*")
                && !operacion.contains("/")
                && !operacion.contains("√")
                && !operacion.contains(".")
                && !operacion.contains("sen")
                && !operacion.contains("cos")
                && !operacion.contains("pow")) {

            double numero = Double.parseDouble(operacion);
            String id = boton.getId();

            switch (id) {
                case "btnRaiz" -> {
                    textOperacion.setText("√" + numero);
                    textResultado.setText(String.valueOf(Math.sqrt(numero)));
                }
                case "btnSeno" -> {
                    textOperacion.setText("sen" + numero);
                    textResultado.setText(String.valueOf(Math.sin(numero)));
                }
                case "btnCoseno" -> {
                    textOperacion.setText("cos" + numero);
                    textResultado.setText(String.valueOf(Math.cos(numero)));
                }
                case "btnPotencia" -> {
                    textOperacion.setText(numero + "pow");
                    textResultado.setText("");
                }
            }
        }
    }


    private void pulsarIgual(Button boton) {
        String expresion = textOperacion.getText();
        if (expresion == null || expresion.isEmpty()) return;

        char ultimoCaracter = expresion.charAt(expresion.length() - 1);


        if (expresion.contains("pow")) {
            String numeroRegex = "-?\\d+(\\.\\d+)?";
            int posicionPow = expresion.indexOf("pow");
            String baseTexto = expresion.substring(0, posicionPow).trim();
            String exponenteTexto = expresion.substring(posicionPow + 3).trim();

            if (!baseTexto.isEmpty()
                    && !exponenteTexto.isEmpty()
                    && baseTexto.matches(numeroRegex)
                    && exponenteTexto.matches(numeroRegex)) {

                double base = Double.parseDouble(baseTexto);
                double exponente = Double.parseDouble(exponenteTexto);
                textResultado.setText(String.valueOf(Math.pow(base, exponente)));
            }
            return;
        }

        // No calcular si el último carácter es un operador, raíz o punto
        if (ultimoCaracter != '-'
                && ultimoCaracter != '+'
                && ultimoCaracter != '/'
                && ultimoCaracter != '*'
                && ultimoCaracter != '√'
                && ultimoCaracter != '.') {

            double resultado = operar(expresion);
            textResultado.setText(String.valueOf(resultado));
        }
    }

    private double operar(String expresion) {
        // Regex para números (decimales, acepta ".5" pero sin signo)
        java.util.regex.Pattern numPattern = java.util.regex.Pattern.compile("\\d*\\.?\\d+");
        java.util.regex.Matcher numMatcher = numPattern.matcher(expresion);

        // Regex para operadores (incluye signos que pueden actuar como signo de un número)
        java.util.regex.Pattern opPattern = java.util.regex.Pattern.compile("[\\-+*/]");
        java.util.regex.Matcher opMatcher = opPattern.matcher(expresion);

        // Meter todos los numeros en una lista
        java.util.List<String> numeros = new java.util.ArrayList<>();
        while (numMatcher.find()) {
            numeros.add(numMatcher.group());
        }

        //lo mismo con los operadores
        java.util.List<String> operadores = new java.util.ArrayList<>();
        while (opMatcher.find()) {
            operadores.add(opMatcher.group());
        }

        // Multiplicaciones y divisiones primero (izquierda a derecha)
        int i = 0;
        while (i < operadores.size()) {
            String op = operadores.get(i);
            if ("*".equals(op) || "/".equals(op)) {
                double n1 = Double.parseDouble(numeros.get(i));
                double n2 = Double.parseDouble(numeros.get(i + 1));
                double resultado = "*".equals(op) ? n1 * n2 : n1 / n2;
                // Reemplaza el primer número por el resultado y elimina el segundo número y el operador usado
                numeros.set(i, String.valueOf(resultado));
                numeros.remove(i + 1);
                operadores.remove(i);
                // no incrementar i para reevaluar en la misma posición
            } else {
                i++;
            }
        }

        // Sumas y restas después (izquierda a derecha)
        i = 0;
        while (i < operadores.size()) {
            double n1 = Double.parseDouble(numeros.get(i));
            double n2 = Double.parseDouble(numeros.get(i + 1));
            double resultado = "-".equals(operadores.get(i)) ? n1 - n2 : n1 + n2;
            numeros.set(i, String.valueOf(resultado));
            numeros.remove(i + 1);
            operadores.remove(i);
        }

        // El único número que queda es el resultado final en la posición 0
        return Double.parseDouble(numeros.get(0));
    }

    private void limpiarTodo(Button boton) {
        textOperacion.setText("");
        textResultado.setText("0.0");
    }


}
