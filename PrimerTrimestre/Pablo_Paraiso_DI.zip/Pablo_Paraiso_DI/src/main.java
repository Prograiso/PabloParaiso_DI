import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

        int opcion = leer.nextInt();

        do {
            System.out.println("""
                    =====MENU=====
                    Opcion1
                    
                    """);

            switch (opcion) {
                case 1:

                    break;

            }
        }
        while (opcion!=0);
        leer    .close();
    }
    }

