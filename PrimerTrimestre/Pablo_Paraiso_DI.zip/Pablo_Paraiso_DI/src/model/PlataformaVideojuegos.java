package model;

import java.lang.reflect.Array;

public class PlataformaVideojuegos {

  private Array videojuegos;

  Videojuego tomylee = new VideojuegoAccion("tomy","olegames",)

  public PlataformaVideojuegos(){}

    public PlataformaVideojuegos(Array videojuegos) {
        this.videojuegos = videojuegos;
    }

    @Override
    public String toString() {
        return "PlataformaVideojuegos{" +
                "videojuegos=" + videojuegos +
                '}';
    }

    public Array getVideojuegos() {
        return videojuegos;
    }

    public void setVideojuegos(Array videojuegos) {
        this.videojuegos = videojuegos;
    }
}
